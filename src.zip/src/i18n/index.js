import enUS from './en-US/index.js'

export default {
  'en-US': enUS
}
